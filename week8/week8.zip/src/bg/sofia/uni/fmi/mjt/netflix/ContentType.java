package bg.sofia.uni.fmi.mjt.netflix;

public enum ContentType {
    MOVIE,
    SHOW
}
