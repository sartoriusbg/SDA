import bg.sofia.uni.fmi.mjt.markdown.MarkdownConverter;

import java.io.StringReader;
import java.io.StringWriter;

public class Main {
    public static void main(String[] args) {
        StringReader reader = new StringReader("# Heading level 1\n## Heading level 2\n### Heading level 3\n#### Heading level 4\n##### Heading level 5\n###### Heading level 6\nI just love **bold text**.\nLove**is**bold\nItalicized text is the *cat's meow*.\nAlways `.close()` your streams\n`.close()` *your* **eyes**");
        StringWriter writer = new StringWriter();
        MarkdownConverter m = new MarkdownConverter();
        m.convertMarkdown(reader, writer);
        System.out.println(writer);
    }
}