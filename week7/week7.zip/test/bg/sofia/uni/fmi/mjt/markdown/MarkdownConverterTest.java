package bg.sofia.uni.fmi.mjt.markdown;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.StringReader;
import java.io.StringWriter;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class MarkdownConverterTest {

    private MarkdownConverter test;
    @BeforeEach
    void setup() {
        test = new MarkdownConverter();
    }
    @Test
    void convertMarkdownTest() {
        StringReader reader = new StringReader("# Heading level 1\n## Heading level 2\n### Heading level 3\n#### Heading level 4\n##### Heading level 5\n###### Heading level 6\nI just love **bold text**.\nLove**is**bold\nItalicized text is the *cat's meow*.\nAlways `.close()` your streams\n`.close()` *your* **eyes**");
        StringWriter writer = new StringWriter();
        test.convertMarkdown(reader,writer);
        assertEquals("<html>" + System.lineSeparator() +
                "<body>" + System.lineSeparator()+
                "<h1>Heading level 1</h1>" + System.lineSeparator() +
                "<h2>Heading level 2</h2>" + System.lineSeparator() +
                "<h3>Heading level 3</h3>" + System.lineSeparator() +
                "<h4>Heading level 4</h4>" + System.lineSeparator() +
                "<h5>Heading level 5</h5>" + System.lineSeparator() +
                "<h6>Heading level 6</h6>" + System.lineSeparator() +
                "I just love <strong>bold text</strong>." + System.lineSeparator() +
                "Love<strong>is</strong>bold" + System.lineSeparator() +
                "Italicized text is the <em>cat's meow</em>." + System.lineSeparator() +
                "Always <code>.close()</code> your streams" + System.lineSeparator() +
                "<code>.close()</code> <em>your</em> <strong>eyes</strong>" + System.lineSeparator() +
                "</body>" + System.lineSeparator() +
                "</html>", writer.toString());
    }

    /*@Test
    void convertMarkdownTestPath() {

    }*/
}
